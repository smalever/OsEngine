﻿using System.Windows.Controls;

namespace OsEngine.OsaExtension.MVVM.View
{
    /// <summary>
    /// Логика взаимодействия для Grid.xaml
    /// </summary>
    public partial class Grid : UserControl
    {
        public Grid()
        {
            InitializeComponent();
        }
    }
}
