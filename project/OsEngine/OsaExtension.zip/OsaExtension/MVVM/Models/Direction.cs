﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OsEngine.OsaExtension.MVVM.Models
{
    /// <summary>
    /// направления сделок 
    /// </summary>
    public enum Direction
    {
        BUY,
        SELL,
        BUYSELL
    }
}
